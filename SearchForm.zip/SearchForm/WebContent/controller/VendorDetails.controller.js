sap.ui.define([ "sap/ui/demo/training/controller/BaseController",
                "sap/ui/model/Filter",
                "sap/ui/model/FilterOperator",
                'sap/m/MessageBox',
                'sap/m/MessageToast'], function(BaseController, MessageBox, MessageToast) {
	"use strict";
	// We define the app controller in its own file by extending the controller
	// object of the SAPUI5 core.
	return BaseController.extend("sap.ui.demo.training.controller.VendorDetails", {
		onInit : function() {
			
			var model1=new sap.ui.model.json.JSONModel();
			model1.loadData("model/vendorDetails.json");
			this.getView().setModel(model1);
			//alert();
		
			
			
		
		},
		onNavButtonPress: function(){
			this.getRouter().navTo("MainPage", {}, true);
			
		},
		onSubmit: function(){
			var oRouter = this.getRouter();
			oRouter.navTo("MainPage");
			sap.ui.controller("sap.ui.demo.training.controller.mainPage").createClear();
		},
		onPresstest:function(){
			alert();
		},
		onSelectChange:function(oEvent){
			var aFilter=[];
			var query1=this.getView().byId("slName").getSelectedItem().getText();
			var query2=this.getView().byId("slNum").getSelectedItem().getText();
			var query3=this.getView().byId("slCreated").getSelectedItem().getText();
			
			var len=this.getView().getModel().getProperty("/vendorDetails").length;
			
			for(var i=0;i<len;i++){
				var vname=this.getView().getModel().getProperty("/vendorDetails")[i].vendorNumber;
				var vnum=this.getView().getModel().getProperty("/vendorDetails")[i].vendorName;
				var cby=this.getView().getModel().getProperty("/vendorDetails")[i].createdBy;
				if(vname==query2){
					if(vnum==query1){
						if(cby==query3)
					{
					
					var jsonModel=this.getView().getModel().getProperty("/vendorDetails")[i];
					
					var oTable=this.getView().byId("Tableid");
					
					oTable.bindItems("/", new sap.m.ColumnListItem("listItem",{
		                cells : [ 
		                new sap.m.Text({text : jsonModel.vendorNumber}),
		                new sap.m.Text({text : jsonModel.vendorName }),
		                new sap.m.Text({text : jsonModel.createdBy}),
		                new sap.m.Text({text : jsonModel.createdDate}),
		                new sap.m.Text({text : [jsonModel.address.Street1 +"\n"+ jsonModel.address.street2+" "+ jsonModel.address.City+"\n"+jsonModel.address.State+" "+jsonModel.address.Country+"\n"+jsonModel.address.PostalCode]}),
		                new sap.m.Text({text : [jsonModel.Contact.email+"\n"+ jsonModel.Contact.telephone+"\n"+jsonModel.Contact.mobile+"\n"+ jsonModel.Contact.fax]})
		               ]
					}));
					}
		
					
				}
				/*
				 * var model2=new sap.ui.model.json.JSONModel();
				 * 
				 * model2.setData(jsonModel); sap.ui.getCore().setModel(model2,
				 * "newModel");
				 */
					}
				
			
			}
			
			
			/*
			 * model2.loadData("model/FilteredDetails.json");
			 * this.getView().setModel(model2);
			 * 
			 * alert(model2.oData.vendorNumber);
			 * 
			 * var oTable=this.getView().byId("Tableid");
			 * oTable.bindItems("/vDetails", new
			 * sap.m.ColumnListItem("listItem",{ cells : [ new sap.m.Text({text :
			 * this.getView().getModel().oData.vendorNumber}) , new
			 * sap.m.Text({text : ""})] }));
			 */		
			/*
			 * var tableitems=[]; for(var i=0;i<len;i++){
			 * 
			 * var
			 * item=this.getView().getModel().getProperty("/vendorDetails")[i].vendorNumber;
			 * var otable=this.getView().byId("Tableid");
			 * 
			 * var oBinding=otable.getBinding("items"); if(query==item){ var
			 * nameFilter = new sap.ui.model.Filter(item,
			 * sap.ui.model.FilterOperator.Contains, query);
			 * aFilter.push(nameFilter); } } oBinding.filter(aFilter); because
			 * in case of label with an empty text,
			 * 
			 * this.getView().byId("Tableid").getModel().refresh(true);
			 * alert(aFilter);
			 */
			this.getView().byId("Tableid").getModel().refresh(true);
			if(jsonModel==null){
				//alert("No valid data");
				sap.m.MessageBox.alert("Please select Valid data");
			}
		},
		homePress2:function(){
			
			this.getRouter().navTo("MainPage", {}, true /* no history */);
		}
		
	});
});