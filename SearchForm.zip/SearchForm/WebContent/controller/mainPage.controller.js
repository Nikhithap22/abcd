sap.ui.define(
				[ "sap/ui/demo/training/controller/BaseController" ],
				function(BaseController) {
					"use strict";
					// We define the app controller in its own file by extending
					// the controller
					// object of the SAPUI5 core.
					var selectedKey = "";
					var txt = "";
					var initialLoad="";
					return BaseController.extend(
									"sap.ui.demo.training.controller.mainPage",
									{
										onInit : function() {

										},
										onSubmit : function(oEvent) {
											var vNameId = this.getView().byId("vname").sId;
											var firstName = sap.ui.getCore().byId(vNameId).getValue();

											var vnumId = this.getView().byId("vnum").sId;
											var lastName = sap.ui.getCore().byId(vnumId).getValue();
											
											 if (selectedKey !== "") { } 
											 else {										 
												
												 selectedKey = this.getView().byId("country").getSelectedItem().mProperties.text;
											 }

											 var post = this.getView().byId("pcode").sId;
											 var postal = sap.ui.getCore().byId(post).getValue();
											 
											 this.getView().byId("SimpleForm1").setVisible(false);
												this.getView().byId("SimpleForm2").setVisible(false);
												this.getView().byId("container").setVisible(true);
												this.getView().byId("button1").setVisible(false);
												this.getView().byId("button2").setVisible(false);
												this.getView().byId("homeButton").setVisible(false);
											
												var oRouter = this.getRouter();
												oRouter.navTo("secondpage");
										},
										
																			
										onTile1Press:function(){
											this.getView().byId("SimpleForm1").setVisible(true);
											this.getView().byId("container").setVisible(false);
											this.getView().byId("button1").setVisible(true);
											this.getView().byId("button2").setVisible(true);
											this.getView().byId("homeButton").setVisible(true);
											
										},
										
										onTile2Press:function(){
											this.getView().byId("SimpleForm2").setVisible(true);
											this.getView().byId("container").setVisible(false);
											this.getView().byId("button8").setVisible(true);
											this.getView().byId("button2").setVisible(true);
											this.getView().byId("homeButton").setVisible(true);
											
										},
										onBack:function(){
											this.getView().byId("SimpleForm1").setVisible(false);
											this.getView().byId("SimpleForm2").setVisible(false);
											this.getView().byId("container").setVisible(true);
											this.getView().byId("button1").setVisible(false);
											this.getView().byId("button2").setVisible(false);
											this.getView().byId("homeButton").setVisible(false);
										},
										homePress:function(){
											this.getView().byId("SimpleForm1").setVisible(false);
											this.getView().byId("SimpleForm2").setVisible(false);
											this.getView().byId("container").setVisible(true);
											this.getView().byId("button1").setVisible(false);
											this.getView().byId("button2").setVisible(false);
											this.getView().byId("homeButton").setVisible(false);
										},
										onSubmitPO:function(){
											var PONum = this.getView().byId("ponum").sId;
											var POnumber = sap.ui.getCore().byId(PONum).getValue();

											var vnumId = this.getView().byId("vnum2").sId;
											var VNumber = sap.ui.getCore().byId(vnumId).getValue();
											
											 var POstatusID = this.getView().byId("postatus").sId;
											 var POstatus = sap.ui.getCore().byId(POstatusID).getValue();
											 
											 this.getView().byId("SimpleForm1").setVisible(false);
												this.getView().byId("SimpleForm2").setVisible(false);
												this.getView().byId("container").setVisible(true);
												this.getView().byId("button1").setVisible(false);
												this.getView().byId("button2").setVisible(false);
												this.getView().byId("homeButton").setVisible(false);
											
											 
											 var oRouter = this.getRouter();
												oRouter.navTo("thirdpage");
										}
									
										
									});
				});