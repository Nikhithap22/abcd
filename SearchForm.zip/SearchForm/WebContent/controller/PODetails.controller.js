sap.ui.define([ "sap/ui/demo/training/controller/BaseController",
                "sap/ui/model/Filter",
                "sap/ui/model/FilterOperator",
                'sap/ui/core/util/Export',
        		'sap/ui/core/util/ExportTypeCSV'], 
                function( BaseController, Export,ExportTypeCSV, MessageBox,JSONModel) {
	"use strict";
	// We define the app controller in its own file by extending the controller
	// object of the SAPUI5 core.
	return BaseController.extend("sap.ui.demo.training.controller.PODetails", {
		onInit : function() {

			var model1 = new sap.ui.model.json.JSONModel();
			model1.loadData("model/POdetails.json");
			this.getView().setModel(model1);
		
			/*
			 * this.aKeys = ["PO Number", "Vendor Number", "PO status"];
			 * this.oSelectName = this.getSelect("PONumber");
			 * this.oSelectCategory = this.getSelect("vendorNumber");
			 * this.oSelectSupplierName = this.getSelect("POstatus");
			 * this.model1.setProperty("/Filter/text", "Filtered by None");
			 * this.addSnappedLabel();
			 */

		},
		/*
		 * getSelect : function (sId) { return this.getView().byId(sId); },
		 */
		addSnappedLabel : function() {
			var oSnappedLabel = this.getSnappedLabel();
			oSnappedLabel
					.attachBrowserEvent("click", this.onToggleHeader, this);
			this.getPageTitle().addSnappedContent(oSnappedLabel);
		},

		onNavButtonPress : function() {
			this.getRouter().navTo("MainPage", {}, true);
			this.getView().byId("SimpleForm2").setVisible(true);
			this.getView().byId("container").setVisible(false);
			this.getView().byId("button1").setVisible(true);
			this.getView().byId("button2").setVisible(true);
			this.getView().byId("homeButton").setVisible(true);
		},
		onSubmit : function() {
			var oRouter = this.getRouter();
			oRouter.navTo("MainPage");
			sap.ui.controller("sap.ui.demo.training.controller.mainPage")
					.createClear();
		},
		homePress2 : function() {
			this.getRouter().navTo("MainPage", {}, true );
			
		},
		onSelectChange : function(oevent) {

			
				var aFilter=[];
				var query1=this.getView().byId("slnum").getSelectedItem().getText();
				var query2=this.getView().byId("slvnum").getSelectedItem().getText();
				var query3=this.getView().byId("slStatus").getSelectedItem().getText();
				
				var len=this.getView().getModel().getProperty("/purchaseOrder").length;
				
				for(var i=0;i<len;i++){
					var ponum=this.getView().getModel().getProperty("/purchaseOrder")[i].PONumber;
					var vnum=this.getView().getModel().getProperty("/purchaseOrder")[i].vendorNumber;
					var status=this.getView().getModel().getProperty("/purchaseOrder")[i].POstatus;
					if(ponum==query1){
						if(vnum==query2){
							if(status==query3)
						{
						
						var jsonModel=this.getView().getModel().getProperty("/purchaseOrder")[i];
						
						var oTable=this.getView().byId("idProductsTable");
						
						oTable.bindItems("/", new sap.m.ColumnListItem("listItem",{
			                cells : [ 
			                new sap.m.Text({text : jsonModel.PONumber}),
			                new sap.m.Text({text : jsonModel.vendorNumber }),
			                new sap.m.Text({text : jsonModel.POstatus}),
			                new sap.m.Text({text : jsonModel.createdDate}),
			               new sap.m.Text({text : [jsonModel.items.itemName +"\n"+"Quantity:"+ jsonModel.items.itemnumber+"\n"+"Vendor Name:"+ jsonModel.items.vendorName+"\n"+"Requested By:"+jsonModel.items.requestedby]}),
			                
			               ]}));
						}
			
					}
					
				}
					
			}
				this.getView().byId("idProductsTable").getModel().refresh(true);
				if(jsonModel==null){
					//alert("No valid data");
					sap.m.MessageBox.alert("Please select Valid data");
				}
			},
			onDataExport: sap.m.Table.prototype.exportData || function(oEvent) {

				var oModel = sap.ui.getCore().getModel("model1");
				var oExport = new Export({

					exportType: new ExportTypeCSV({
						fileExtension: "csv",
						separatorChar: ";"
					}),

					models: oModel,

					rows: {
						path: "/purchaseOrder"
					},
					columns: [{
						name: "PO Number",
						template: {
							content: "{PONumber}"
						}
					}, {
						name: "vendor Number",
						template: {
							content: "{vendorNumber}"
						}
					}, {
						name: "created Date",
						template: {
							content: "{createdDate}"
						}
					}, {
						name: "PO Status",
						template: {
							content: "{POstatus}"
						}
					}]
				});
				console.log(oExport);
				
			},

		handlePopoverPress : function(oEvent) {

			// create popover
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment(
						"sap.ui.demo.training.fragment.itemdetails", this);
				this.getView().addDependent(this._oPopover);
				this._oPopover.bindElement("/purchaseOrder/0/items");
			}

			// delay because addDependent will do a async rerendering and the
			// actionSheet will immediately close without it.
			var oButton = oEvent.getSource();
			jQuery.sap.delayedCall(0, this, function() {
				this._oPopover.openBy(oButton);
			});
		},

	});
});